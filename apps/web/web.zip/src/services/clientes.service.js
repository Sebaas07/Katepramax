import clientesApi from "@/api/clientesApi";
import { tieneAccesoTotal, obtenerSedeUsuario } from "@/utils/permisos";

/**
 * clientes.service.js — Katepramax
 * Lógica de negocio del lado cliente para el módulo de clientes.
 * Alineado con el schema Prisma real: nombre, telefono, limiteCredito, saldoDeuda, activo.
 * No incluye "identificacion" ni "email" — esos campos no existen en el modelo.
 * Reglas de sede:
 * - Admin: acceso total (no filtra por sede)
 * - Bodega/AdminBogota: solo su sede
 */
const clientesService = {
  obtenerClientes: async (filtros = {}) => {
    try {
      const f = { ...filtros };
      // Si no es Admin, filtrar por sede automáticamente
      if (!tieneAccesoTotal()) {
        const sedeIdUsuario = obtenerSedeUsuario();
        if (sedeIdUsuario) {
          f.sedeId = sedeIdUsuario;
        }
      }
      const clientes = await clientesApi.obtenerClientes(f);
      return clientes;
    } catch (error) {
      console.error("Error en clientesService.obtenerClientes:", error);
      throw error;
    }
  },

  obtenerClientePorId: async (id) => {
    try {
      const cliente = await clientesApi.obtenerClientePorId(id);
      return cliente;
    } catch (error) {
      console.error("Error en clientesService.obtenerClientePorId:", error);
      throw error;
    }
  },

  crearCliente: async (clienteData) => {
    try {
      // Validación alineada con el schema real
      if (!clienteData.nombre || !clienteData.nombre.trim()) {
        throw new Error("El nombre del cliente es obligatorio.");
      }
      // El backend solo acepta estos campos en la creación
      // ("activo" no aplica: todo cliente nuevo nace activo).
      const payload = {
        nombre: clienteData.nombre,
        telefono: clienteData.telefono || undefined,
        sedeId: clienteData.sedeId !== undefined ? clienteData.sedeId : undefined,
        limiteCredito:
          clienteData.limiteCredito !== undefined
            ? clienteData.limiteCredito
            : undefined,
        saldoDeuda:
          clienteData.saldoDeuda !== undefined
            ? clienteData.saldoDeuda
            : undefined,
      };
      Object.keys(payload).forEach(
        (k) => payload[k] === undefined && delete payload[k],
      );
      const nuevoCliente = await clientesApi.crearCliente(payload);
      return nuevoCliente;
    } catch (error) {
      console.error("Error en clientesService.crearCliente:", error);
      throw error;
    }
  },

  actualizarCliente: async (id, clienteData) => {
    try {
      if (!id) throw new Error("Se requiere el ID del cliente.");
      if (!clienteData || Object.keys(clienteData).length === 0) {
        throw new Error("No hay datos para actualizar.");
      }
      const clienteActualizado = await clientesApi.actualizarCliente(id, clienteData);
      return clienteActualizado;
    } catch (error) {
      console.error("Error en clientesService.actualizarCliente:", error);
      throw error;
    }
  },

  desactivarCliente: async (id) => {
    try {
      if (!id) throw new Error("Se requiere el ID del cliente.");
      const resultado = await clientesApi.desactivarCliente(id);
      return resultado;
    } catch (error) {
      console.error("Error en clientesService.desactivarCliente:", error);
      throw error;
    }
  },

  abonarCliente: async (id, monto) => {
    try {
      if (!id) throw new Error("Se requiere el ID del cliente.");
      const valor = parseFloat(monto);
      if (isNaN(valor) || valor <= 0) {
        throw new Error("El monto del abono debe ser mayor a 0.");
      }
      const clienteActualizado = await clientesApi.abonarCliente(id, valor);
      return clienteActualizado;
    } catch (error) {
      console.error("Error en clientesService.abonarCliente:", error);
      throw error;
    }
  },
};

export default clientesService;