import { useState, useEffect, useCallback, useMemo } from "react";
import { toast } from "react-hot-toast";
import { useAuth } from "@/hooks/useAuth";
import entregaService from "@/services/entrega.service";
import inventarioService from "@/services/inventario.service";
import TablaGenerica from "@/components/common/TablaGenerica/TablaGenerica";
import Modal from "@/components/common/Modal/Modal";
import EstadoBadge from "@/components/common/EstadoBadge/EstadoBadge";
import EmptyState from "@/components/common/EmptyState/EmptyState";
import DatePicker from "@/components/common/DatePicker/DatePicker";
import { formatCOP, formatFecha } from "@/utils/formatters";
import "./EntregasPage.css";

const POLLING_INTERVAL_MS = 20000;

const Spinner = () => (
  <div className="entr-spinner-wrap">
    <div className="entr-spinner" />
    <span>Cargando tus entregas...</span>
  </div>
);

const TarjetaEntrega = ({
  asignacion,
  sedes,
  onSalida,
  onConfirmar,
  onFallo,
}) => {
  const estado = asignacion.estado;
  const pedido = asignacion.pedido;
  const estadoNormalizado =
    estado === "EnRuta" ? "en_ruta" : estado?.toLowerCase();

  const totalPedido = useMemo(() => {
    const items = pedido?.detalles ?? pedido?.items ?? [];
    return items.reduce((acc, it) => {
      const cant = parseInt(it.cantidad ?? 0, 10);
      const precio = parseFloat(
        it.precioUnitario ?? it.precio_unitario ?? it.precio ?? 0,
      );
      return (
        acc +
        (Number.isNaN(cant) ? 0 : cant) * (Number.isNaN(precio) ? 0 : precio)
      );
    }, 0);
  }, [pedido]);

  const resumenProductos = useMemo(() => {
    const items = pedido?.detalles ?? pedido?.items ?? [];
    return items
      .slice(0, 3)
      .map(
        (it) =>
          it.producto?.descripcion ??
          it.producto?.nombre ??
          `#${it.productoId}`,
      )
      .join(", ");
  }, [pedido]);

  const nombreSede = (sedeId) => {
    const sede = sedes.find((s) => s.id === sedeId);
    return sede?.nombre ?? `Sede ${sedeId ?? "—"}`;
  };

  return (
    <div className={`entr-card entr-card--${estadoNormalizado}`}>
      <div className="entr-card-header">
        <div className="entr-card-id">
          <span className="material-symbols-outlined">shopping_bag</span>
          Pedido #{pedido?.id ?? asignacion.pedidoId}
        </div>
        <EstadoBadge estado={estadoNormalizado} />
      </div>

      <div className="entr-card-body">
        <div className="entr-info-row">
          <span className="material-symbols-outlined entr-icon">person</span>
          <span>{pedido?.cliente?.nombre ?? "—"}</span>
        </div>

        <div className="entr-info-row">
          <span className="material-symbols-outlined entr-icon">
            location_on
          </span>
          <span>{pedido?.direccion ?? "—"}</span>
        </div>

        <div className="entr-info-row">
          <span className="material-symbols-outlined entr-icon">store</span>
          <span>{nombreSede(pedido?.sedeId ?? pedido?.sede?.id)}</span>
        </div>

        {resumenProductos && (
          <div className="entr-info-row">
            <span className="material-symbols-outlined entr-icon">
              inventory
            </span>
            <span className="entr-productos-resumen">{resumenProductos}</span>
          </div>
        )}

        <div className="entr-info-row">
          <span className="material-symbols-outlined entr-icon">
            attach_money
          </span>
          <strong className="entr-total">{formatCOP(totalPedido)}</strong>
        </div>

        {pedido?.creadoEn && (
          <div className="entr-info-row">
            <span className="material-symbols-outlined entr-icon">
              schedule
            </span>
            <span>{formatFecha(pedido.creadoEn)}</span>
          </div>
        )}
      </div>

      <div className="entr-card-footer">
        {estado === "Pendiente" && (
          <button
            className="entr-btn entr-btn--salida"
            onClick={() => onSalida(asignacion)}
            type="button"
          >
            <span className="material-symbols-outlined">directions_bike</span>
            Salí
          </button>
        )}

        {estado === "EnRuta" && (
          <>
            <button
              className="entr-btn entr-btn--confirmar"
              onClick={() => onConfirmar(asignacion)}
              type="button"
            >
              <span className="material-symbols-outlined">check_circle</span>
              Entregado
            </button>
            <button
              className="entr-btn entr-btn--fallo"
              onClick={() => onFallo(asignacion)}
              type="button"
            >
              <span className="material-symbols-outlined">cancel</span>
              Fallido
            </button>
          </>
        )}

        {estado === "Entregado" && (
          <div className="entr-entregado-info">
            <span className="material-symbols-outlined">check_circle</span>
            <span>{formatCOP(asignacion.montoCobrado)}</span>
            {asignacion.metodoPago && (
              <span className="entr-metodo"> · {asignacion.metodoPago}</span>
            )}
          </div>
        )}

        {estado === "Fallido" && (
          <div className="entr-fallido-info">
            <span className="material-symbols-outlined">cancel</span>
            <span>Entrega fallida</span>
            {asignacion.observacionesEntrega && (
              <span className="entr-obs">
                {" "}
                — {asignacion.observacionesEntrega}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

const EntregasPage = () => {
  const { usuario, isAuthenticated, isSessionChecked } = useAuth();

  const [entregas, setEntregas] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [errorDatos, setErrorDatos] = useState(null);
  const [sedes, setSedes] = useState([]);
  const [cargandoSedes, setCargandoSedes] = useState(false);

  const [modalConfirmarAbierto, setModalConfirmarAbierto] = useState(false);
  const [modalFalloAbierto, setModalFalloAbierto] = useState(false);
  const [asignacionActiva, setAsignacionActiva] = useState(null);

  const [formConfirmar, setFormConfirmar] = useState({
    montoCobrado: "",
    metodoPago: "Efectivo",
    montoEfectivo: "",
    montoTransferencia: "",
    abonoDeuda: "",
    observaciones: "",
    fechaConfirmada: new Date().toISOString().slice(0, 16),
  });
  const [motivoFallo, setMotivoFallo] = useState("");

  // Detectar ancho de pantalla para responsive
  const [anchoPantalla, setAnchoPantalla] = useState(window.innerWidth);
  useEffect(() => {
    const handleResize = () => setAnchoPantalla(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const usarTarjetas = anchoPantalla < 768;

  useEffect(() => {
    if (!isSessionChecked || !isAuthenticated) return;

    const cargarSedes = async () => {
      setCargandoSedes(true);
      try {
        const data = await inventarioService.obtenerSedes();
        setSedes(Array.isArray(data) ? data : []);
      } catch (err) {
        console.error("Error al cargar sedes:", err);
        setSedes([]);
      } finally {
        setCargandoSedes(false);
      }
    };

    void cargarSedes();
  }, [isSessionChecked, isAuthenticated]);

  // ── Carga de datos ───────────────────────────────────────────────
  const cargarEntregas = useCallback(async () => {
    setCargando(true);
    setErrorDatos(null);
    try {
      const data = await entregaService.obtenerMisEntregas();
      setEntregas(data);
    } catch (err) {
      setErrorDatos(
        "No se pudieron cargar las entregas. Verifica tu conexión.",
      );
      toast.error("Error al cargar entregas: " + err.message);
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    if (!isSessionChecked || !isAuthenticated) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    cargarEntregas();

    const intervalo = setInterval(cargarEntregas, POLLING_INTERVAL_MS);
    return () => clearInterval(intervalo);
  }, [cargarEntregas, isSessionChecked, isAuthenticated]);

  // ── Handlers de acciones ───────────────────────────────────────────
  const handleSalida = async (asignacion) => {
    try {
      await entregaService.marcarSalida(asignacion.id);
      toast.success("¡Listo! Estás en ruta.");
      await cargarEntregas();
    } catch (err) {
      toast.error(err.message);
    }
  };

  const abrirConfirmar = (asignacion) => {
    setAsignacionActiva(asignacion);
    setFormConfirmar({
      montoCobrado: "",
      metodoPago: "Efectivo",
      montoEfectivo: "",
      montoTransferencia: "",
      abonoDeuda: "",
      observaciones: "",
      fechaConfirmada: new Date().toISOString().slice(0, 16),
    });
    setModalConfirmarAbierto(true);
  };

  const handleConfirmar = async () => {
    setGuardando(true);
    try {
      await entregaService.confirmarEntrega(asignacionActiva.id, {
        montoCobrado: formConfirmar.metodoPago === "Credito" ? 0 : formConfirmar.montoCobrado,
        metodoPago: formConfirmar.metodoPago,
        montoEfectivo: formConfirmar.montoEfectivo,
        montoTransferencia: formConfirmar.montoTransferencia,
        abonoDeuda: formConfirmar.abonoDeuda,
        observaciones: formConfirmar.observaciones,
        fechaConfirmada: formConfirmar.fechaConfirmada,
      });
      toast.success("Entrega confirmada correctamente.");
      setModalConfirmarAbierto(false);
      await cargarEntregas();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setGuardando(false);
    }
  };

  const abrirFallo = (asignacion) => {
    setAsignacionActiva(asignacion);
    setMotivoFallo("");
    setModalFalloAbierto(true);
  };

  const handleFallo = async () => {
    setGuardando(true);
    try {
      await entregaService.registrarFallo(asignacionActiva.id, motivoFallo);
      toast.success("Fallo registrado. El pedido vuelve a Pendiente.");
      setModalFalloAbierto(false);
      await cargarEntregas();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setGuardando(false);
    }
  };

  // ── Columnas para tabla ──────────────────────────────────────────
  const columnas = [
    { campo: "id", label: "ID", tipo: "texto" },
    { campo: "cliente", label: "Cliente", tipo: "texto" },
    { campo: "direccion", label: "Dirección", tipo: "texto" },
    { campo: "sede", label: "Sede", tipo: "texto" },
    { campo: "total", label: "Total Pedido ($)", tipo: "moneda" },
    { campo: "costoRecibido", label: "Costo Recibido ($)", tipo: "moneda" },
    { campo: "metodoPago", label: "Método de Pago", tipo: "texto" },
    { campo: "estado", label: "Estado", tipo: "estado" },
  ];

  // Mapear datos para tabla
  const entregasMapeadas = useMemo(() => {
    return entregas.map((asig) => {
      const pedido = asig.pedido ?? {};
      const items = pedido.detalles ?? pedido.items ?? [];
      const total = items.reduce((acc, it) => {
        const cant = parseInt(it.cantidad ?? 0, 10);
        const precio = parseFloat(
          it.precioUnitario ?? it.precio_unitario ?? it.precio ?? 0,
        );
        return (
          acc +
          (Number.isNaN(cant) ? 0 : cant) * (Number.isNaN(precio) ? 0 : precio)
        );
      }, 0);

      const sedeObj = sedes.find((s) => s.id === pedido.sedeId);

      return {
        id: `#${pedido.id ?? asig.pedidoId ?? ""}`,
        cliente:
          pedido.cliente?.nombre ?? `Cliente #${pedido.clienteId ?? "—"}`,
        direccion: pedido.direccion ?? "—",
        sede: sedeObj?.nombre ?? `Sede ${pedido.sedeId ?? "—"}`,
        total,
        costoRecibido:
          asig.estado === "Entregado" ? Number(asig.montoCobrado ?? 0) : 0,
        metodoPago:
          asig.estado === "Entregado" ? (asig.metodoPago ?? "—") : "—",
        estado:
          asig.estado === "EnRuta" ? "en_ruta" : asig.estado?.toLowerCase(),
        asignacionId: asig.id,
        pedidoId: pedido.id ?? asig.pedidoId,
      };
    });
  }, [entregas, sedes]);

  // Contadores
  const pendientes = entregas.filter((e) => e.estado === "Pendiente").length;
  const enRuta = entregas.filter((e) => e.estado === "EnRuta").length;

  const accionesEntregas = (fila) => {
    const asig = entregas.find((a) => a.id === fila.asignacionId);
    if (!asig) return [];
    const accs = [];
    if (asig.estado === "Pendiente") {
      accs.push({
        label: "En Ruta",
        icon: "directions_bike",
        onClick: () => handleSalida(asig),
        variante: "success",
      });
      accs.push({
        label: "Fallido",
        icon: "cancel",
        onClick: () => abrirFallo(asig),
        variante: "danger",
      });
    } else if (asig.estado === "EnRuta") {
      accs.push({
        label: "Entregado",
        icon: "check_circle",
        onClick: () => abrirConfirmar(asig),
        variante: "success",
      });
      accs.push({
        label: "Fallido",
        icon: "cancel",
        onClick: () => abrirFallo(asig),
        variante: "danger",
      });
    }
    return accs;
  };

  // ── Render ─────────────────────────────────────────────────────────
  return (
    <div className="entregas-page">
      <div className="page-header">
        <div>
          <h1>Mis Entregas</h1>
          <p className="entr-subtitulo">
            {usuario?.nombreCompleto ?? "Entregador"} — Rol: {usuario?.rol}
          </p>
        </div>

        <div className="entr-header-acciones">
          <div className="entr-kpis">
            <div className="entr-kpi">
              <span className="entr-kpi-valor">{pendientes}</span>
              <span className="entr-kpi-label">Pendientes</span>
            </div>
            <div className="entr-kpi entr-kpi--ruta">
              <span className="entr-kpi-valor">{enRuta}</span>
              <span className="entr-kpi-label">En ruta</span>
            </div>
          </div>

          <button
            className="btn-outline"
            onClick={cargarEntregas}
            disabled={cargando}
            type="button"
          >
            <span className="material-symbols-outlined">refresh</span>
            Actualizar
          </button>
        </div>
      </div>

      <div className="tab-content">
        {cargando ? (
          <Spinner />
        ) : errorDatos ? (
          <EmptyState
            icon="cloud_off"
            title="Error de conexión"
            description={errorDatos}
            actionLabel="Reintentar"
            onAction={cargarEntregas}
          />
        ) : entregas.length === 0 ? (
          <EmptyState
            icon="local_shipping"
            title="Sin entregas"
            description="No tienes entregas asignadas."
            subDescription="Cuando se asignen pedidos, aparecerán aquí."
          />
        ) : usarTarjetas ? (
          <div className="entr-grid">
            {entregas.map((asignacion) => (
              <TarjetaEntrega
                key={asignacion.id}
                asignacion={asignacion}
                sedes={sedes}
                onSalida={handleSalida}
                onConfirmar={abrirConfirmar}
                onFallo={abrirFallo}
              />
            ))}
          </div>
        ) : (
          <TablaGenerica
            columnas={columnas}
            datos={entregasMapeadas}
            filasPorPagina={10}
            mostrarBuscador={false}
            paginacion
            renderAcciones={accionesEntregas}
          />
        )}
      </div>

      {/* Modal — Confirmar entrega */}
      <Modal
        isOpen={modalConfirmarAbierto}
        onClose={() => setModalConfirmarAbierto(false)}
        titulo="Confirmar Entrega"
        textoBotonConfirmar={guardando ? "Confirmando..." : "Confirmar"}
        onConfirmar={handleConfirmar}
        mostrarCancelar
        disabled={guardando}
      >
        <div className="modal-form">
          {asignacionActiva && (
            <div className="form-group">
              <label>
                Pedido #
                {asignacionActiva.pedido?.id ?? asignacionActiva.pedidoId}
              </label>
              <p className="entr-pedido-info">
                {asignacionActiva.pedido?.cliente?.nombre ?? "—"}
                {asignacionActiva.pedido?.direccion && (
                  <span className="entr-pedido-dir">
                    {" "}
                    — {asignacionActiva.pedido.direccion}
                  </span>
                )}
              </p>
              {asignacionActiva.pedido && (
                <p className="entr-pedido-total">
                  Total del pedido:{" "}
                  <strong>
                    {formatCOP(
                      (
                        asignacionActiva.pedido.detalles ??
                        asignacionActiva.pedido.items ??
                        []
                      ).reduce(
                        (acc, it) =>
                          acc +
                          parseInt(it.cantidad ?? 0, 10) *
                            parseFloat(it.precioUnitario ?? 0),
                        0,
                      ),
                    )}
                  </strong>
                </p>
              )}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="entr-fecha">Fecha y Hora Confirmada *</label>
            <DatePicker
              id="entr-fecha"
              enableTime
              value={formConfirmar.fechaConfirmada}
              onChange={(e) =>
                setFormConfirmar((p) => ({
                  ...p,
                  fechaConfirmada: e.target.value,
                }))
              }
              className="form-control"
            />
          </div>

          <div className="form-group">
            <label htmlFor="entr-monto">Monto Cobrado ($) *</label>
            <input
              id="entr-monto"
              type="number"
              value={formConfirmar.metodoPago === "Credito" ? 0 : formConfirmar.montoCobrado}
              onChange={(e) =>
                setFormConfirmar((p) => ({
                  ...p,
                  montoCobrado: e.target.value,
                }))
              }
              className="form-control"
              min="0"
              step="100"
              placeholder="0"
              disabled={formConfirmar.metodoPago === "Credito"}
            />
            {formConfirmar.metodoPago === "Credito" && (
              <span className="form-hint">
                Con pago a crédito no se cobra nada ahora; el pedido queda como deuda del cliente.
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="entr-metodo">Forma de Pago *</label>
            <select
              id="entr-metodo"
              value={formConfirmar.metodoPago}
              onChange={(e) =>
                setFormConfirmar((p) => ({ ...p, metodoPago: e.target.value }))
              }
              className="form-control"
            >
              <option value="Efectivo">Efectivo</option>
              <option value="Transferencia">Transferencia</option>
              <option value="Mixto">Mixto (efectivo + transferencia)</option>
              <option value="Parcial">Pago parcial</option>
              <option value="Credito">Crédito (no cobra ahora)</option>
            </select>
          </div>

          {formConfirmar.metodoPago === "Mixto" && (
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="entr-efectivo">Monto en Efectivo ($) *</label>
                <input
                  id="entr-efectivo"
                  type="number"
                  value={formConfirmar.montoEfectivo}
                  onChange={(e) =>
                    setFormConfirmar((p) => ({ ...p, montoEfectivo: e.target.value }))
                  }
                  className="form-control"
                  min="0"
                  step="100"
                  placeholder="0"
                />
              </div>
              <div className="form-group">
                <label htmlFor="entr-transferencia">Monto en Transferencia ($) *</label>
                <input
                  id="entr-transferencia"
                  type="number"
                  value={formConfirmar.montoTransferencia}
                  onChange={(e) =>
                    setFormConfirmar((p) => ({ ...p, montoTransferencia: e.target.value }))
                  }
                  className="form-control"
                  min="0"
                  step="100"
                  placeholder="0"
                />
              </div>
              {(() => {
                const suma =
                  (parseFloat(formConfirmar.montoEfectivo) || 0) +
                  (parseFloat(formConfirmar.montoTransferencia) || 0);
                const cobrado = parseFloat(formConfirmar.montoCobrado) || 0;
                const coincide = Math.abs(suma - cobrado) < 0.01;
                return (
                  <span className={`form-hint ${!coincide ? "form-hint--error" : ""}`}>
                    Efectivo + transferencia: {formatCOP(suma)}
                    {!coincide && ` — debe ser igual al monto cobrado (${formatCOP(cobrado)})`}
                  </span>
                );
              })()}
            </div>
          )}

          {Number(asignacionActiva?.pedido?.cliente?.saldoDeuda ?? 0) > 0 && (
            <div className="form-group entr-abono-deuda">
              <label htmlFor="entr-abono">Abono a deuda anterior del cliente (opcional)</label>
              <span className="form-hint">
                Este cliente tiene un saldo pendiente de{" "}
                <strong>
                  {formatCOP(asignacionActiva.pedido.cliente.saldoDeuda)}
                </strong>{" "}
                de pedidos anteriores. Si te entregó dinero extra para esa deuda, regístralo aquí.
              </span>
              <input
                id="entr-abono"
                type="number"
                value={formConfirmar.abonoDeuda}
                onChange={(e) =>
                  setFormConfirmar((p) => ({ ...p, abonoDeuda: e.target.value }))
                }
                className="form-control"
                min="0"
                max={asignacionActiva.pedido.cliente.saldoDeuda}
                step="100"
                placeholder="0"
              />
            </div>
          )}

          <div className="form-group">
            <label htmlFor="entr-obs">Nota (opcional)</label>
            <textarea
              id="entr-obs"
              value={formConfirmar.observaciones}
              onChange={(e) =>
                setFormConfirmar((p) => ({
                  ...p,
                  observaciones: e.target.value,
                }))
              }
              className="form-control"
              rows={2}
              placeholder="Observaciones de la entrega..."
            />
          </div>
        </div>
      </Modal>

      {/* Modal — Registrar fallo */}
      <Modal
        isOpen={modalFalloAbierto}
        onClose={() => setModalFalloAbierto(false)}
        titulo="Registrar Fallo"
        textoBotonConfirmar={guardando ? "Registrando..." : "Registrar"}
        onConfirmar={handleFallo}
        mostrarCancelar
        disabled={guardando}
      >
        <div className="modal-form">
          {asignacionActiva && (
            <div className="form-group">
              <label>
                Pedido #
                {asignacionActiva.pedido?.id ?? asignacionActiva.pedidoId}
              </label>
              <p className="entr-pedido-info">
                {asignacionActiva.pedido?.cliente?.nombre ?? "—"}
              </p>
            </div>
          )}

          <div className="entr-fallo-aviso">
            <span className="material-symbols-outlined">info</span>
            El pedido volverá a <strong>Pendiente</strong> para reasignación.
          </div>

          <div className="form-group">
            <label htmlFor="entr-motivo">Nota del fallo *</label>
            <textarea
              id="entr-motivo"
              value={motivoFallo}
              onChange={(e) => setMotivoFallo(e.target.value)}
              className="form-control"
              rows={3}
              placeholder="Ej: Cliente ausente, dirección incorrecta, no contesta..."
              required
            />
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default EntregasPage;
